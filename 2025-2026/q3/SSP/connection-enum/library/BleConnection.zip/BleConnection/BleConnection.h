#ifndef BLE_CONNECTION_H
#define BLE_CONNECTION_H

#include <Arduino.h>
#include <cstring>
#include <stdint.h>

// --- Shared Protocol Constants ---
#define BLE_SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define BLE_CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"
#define BLE_NUM_IMUS            6
#define BLE_PACKET_SIZE         197

struct ImuSample {
    int16_t ax, ay, az;
    int16_t gx, gy, gz;
};

// --- Library Class ---
class BleConnection {
public:
    BleConnection();

    // --- Server Role (Arduino Nano 33 BLE / nRF52) ---
#if defined(ARDUINO_ARCH_NRF52)
    bool initServer(const char* deviceName);
    void sendData(const ImuSample* samples, uint8_t count);
    bool isConnected();
    void updateServer(); // Optional polling for disconnects
#endif

    // --- Client Role (ESP32 / NimBLE) ---
#if defined(ARDUINO_ARCH_ESP32)
    typedef void (*NotifyCallback)(uint8_t seq, uint32_t ts, ImuSample* samples);
    
    bool initClient(NotifyCallback callback);
    void updateClient();
    bool isConnected();
    bool isScanning();
#endif

private:
    uint8_t _seqOut;
    unsigned long _lastPacketMs;

    // Internal packet packing
    static int packBatch(uint8_t* buf, uint8_t seq, uint32_t ts, const ImuSample* imus, int count);
};

#endif
