/*
 * SPDX-FileCopyrightText: 2025 Kiril V. Strezikozin, Zurab Kvachadze
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <stdio.h>

#include "rotary_encoder/ec11/config.h"
#include "rotary_encoder/ec11/program.h"

#ifdef PICO_DEFAULT_EC11_PIN_BTN
#define EC11_PIN_BTN PICO_DEFAULT_EC11_PIN_BTN
#else
#define EC11_PIN_BTN 2
#endif

#ifdef PICO_DEFAULT_EC11_PIN_A
#define EC11_PIN_A PICO_DEFAULT_EC11_PIN_A
#else
#define EC11_PIN_A 3
#endif

#ifdef PICO_DEFAULT_EC11_PIN_B
#define EC11_PIN_B PICO_DEFAULT_EC11_PIN_B
#else
#define EC11_PIN_B 4
#endif

#define BTN_DEBOUNCE_DELAY_US 10000

/* Callback handlers used for the EC11 Rotary Encoder in this example. */

// See `gpio_irq_callback_t` for parameter description.
static void on_press(uint gpio, uint32_t event_mask)
{
    static absolute_time_t last_press_time = 0;

    // The button callback is set to be triggered on a Rise/Fall signal. It is
    // therefore only necessary to limit the number of presses at a time.
    const absolute_time_t now = time_us_64();
    if (now - last_press_time < BTN_DEBOUNCE_DELAY_US) return;
    last_press_time = now;

    printf("EC11 Rotary Encoder button was pressed\n");
}

static void on_scroll_up(void)
{
    printf("EC11 Rotary Encoder knob was scrolled up\n");
}

static void on_scroll_down(void)
{
    printf("EC11 Rotary Encoder knob was scrolled down\n");
}

int main()
{
    stdio_init_all();
    printf(
        "EC11 Rotary Encoder Smoke Test, using pins %d, %d, %d\n",
        EC11_PIN_BTN,
        EC11_PIN_A,
        EC11_PIN_B
    );

    // Configure the 5-pin EC11 Rotary Encoder component type with A, B, and
    // BTN pins that carry the encoder data. The default configuration options
    // were adjusted to minimize and alleviate electrical noise produced by
    // mechanical parts of the rotary encoder.
    ec11_rotary_encoder_config ec11_config;
    ec11_rotary_encoder_apply_default_config(
        &ec11_config, EC11_PIN_A, EC11_PIN_B
    );
    // The button pin is unassigned by default, set it.
    ec11_rotary_encoder_config_set_pin_btn(&ec11_config, EC11_PIN_BTN);

    // Set callback handlers that are automatically called when the
    // corresponding event occurs.
    ec11_rotary_encoder_config_set_pressed_handler(&ec11_config, on_press);
    ec11_rotary_encoder_config_set_scroll_down_handler(
        &ec11_config, on_scroll_down
    );
    ec11_rotary_encoder_config_set_scroll_up_handler(
        &ec11_config, on_scroll_up
    );

    // Initialize EC11 Rotary Encoder driver instruction program. Data
    // transmission will be set up to proceed in the background. The main
    // Pico's CPU will be requested to call the specified callbacks upon an
    // incoming signal from the encoder (the knob has been rotated or the
    // button has been pressed).
    ec11_rotary_encoder_program_init(&ec11_config, true /* Enable IRQs */);

    ec11_rotary_encoder_program_button_init(
        &ec11_config,
        true /* Use an internal pull up resistor */,
        false,
        true /* Enable IRQs */
    );

    while (true) {
        tight_loop_contents();
    }

    // Unload the State machine program from the PIO assigned to the EC11
    // Rotary Encoder pins. The State machine acquired during initialization
    // will become available for others to use, and the EC11 Rotary Encoder
    // driver instruction program will be unloaded from its memory.
    ec11_rotary_encoder_program_deinit(&ec11_config);
}
