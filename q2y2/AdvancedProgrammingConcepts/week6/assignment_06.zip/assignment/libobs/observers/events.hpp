#ifndef INCLUDED_OBSERVERS_EVENTS_HPP
#define INCLUDED_OBSERVERS_EVENTS_HPP

#include <functional>
#include <unordered_map>
#include <optional>

#include "observers.hpp"

namespace observers
{
  // TODO: implement event here
  
} // namespace observers::events

#endif /* INCLUDED_OBSERVERS_EVENTS_HPP */
